# Run this after fitting your chosen model/pipeline in the Task 4 notebook.
# Replace `best_model` with the actual fitted model variable name.
import joblib
joblib.dump(best_model, "student_pass_fail_model.joblib")
