# Task 5 — Streamlit ML Deployment

A small Streamlit interface for the Student Pass/Fail Prediction project.

## Important

This app requires a trained model file named `student_pass_fail_model.joblib` in the same folder. The model file is intentionally not fabricated: run and evaluate your Task 4 notebook first, then export the fitted pipeline/model. The app's sample input fields must match the exact feature columns and preprocessing expected by your saved model.

## Files

- `app.py` — Streamlit user interface and prediction code
- `requirements.txt` — Python packages
- `student_pass_fail_model.joblib` — add after training your model

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install packages:

   ```bash
   pip install -r requirements.txt
   ```

4. Add the trained model file as described above.
5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL shown in the terminal.

## Exporting the model from your Task 4 notebook

After fitting the model you choose, save the **entire preprocessing + model pipeline** where possible:

```python
import joblib
joblib.dump(best_model, "student_pass_fail_model.joblib")
```

Replace `best_model` with the variable name of your fitted model/pipeline. If your model was trained with a different feature set, edit the input fields in `app.py` to provide the same columns in the same format. If the model expects encoded columns, prefer saving a scikit-learn `Pipeline` that includes the preprocessing steps.

## Deployment

You can deploy this folder using Streamlit Community Cloud after pushing the files to a GitHub repository. Include the model file only if you have permission to share the dataset/model and it does not contain private information.

## Limitations

- The model is an educational demo, not a reliable or official assessment of a student's future.
- Predictions depend on training data and model quality.
- Do not use predictions to make consequential decisions about real students.
- Test the app with known examples before sharing a live link.
