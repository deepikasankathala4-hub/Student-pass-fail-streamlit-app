# Task 5 Report — Streamlit Deployment

## Project title
Student Pass/Fail Prediction — Streamlit Web App

## Objective
Create a simple web interface that lets a user enter student-related inputs and view a prediction from a previously trained machine-learning model.

## Technologies
- Python
- Streamlit
- Pandas
- Scikit-learn
- Joblib

## Application workflow
1. Load the saved, trained model.
2. Collect input values through Streamlit controls.
3. Format the values as a Pandas DataFrame.
4. Pass the input to the model.
5. Display the predicted class and, when supported, estimated class probabilities.

## Files submitted
- `app.py`
- `requirements.txt`
- `README.md`
- `student_pass_fail_model.joblib` — to be added after exporting the fitted model from Task 4

## Testing and results
Complete this section after running the app with the actual Task 4 model:
- App launch successful: [Yes/No]
- Model loaded successfully: [Yes/No]
- Test input used: [Describe]
- Prediction returned: [Record actual result]
- Screenshot saved: [Filename]

Do not claim a successful deployment or report predictions until you have run and tested the application.

## Challenges
The web app must use the same input columns and preprocessing as the trained model. A mismatch between the app inputs and model features can cause prediction errors.

## Future improvements
- Automatically generate the input form from the model's feature schema.
- Add input validation and clearer explanation of model outputs.
- Deploy the app online and test it on multiple devices.
- Improve documentation and accessibility.

## Conclusion
This project demonstrates the deployment step of a basic ML workflow. The app becomes usable after the fitted model from Task 4 is exported and the input fields are aligned with its training features.
