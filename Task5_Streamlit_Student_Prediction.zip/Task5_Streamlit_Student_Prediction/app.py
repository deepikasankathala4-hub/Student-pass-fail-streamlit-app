import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

st.set_page_config(page_title="Student Pass/Fail Predictor", page_icon="🎓", layout="centered")

MODEL_PATH = Path(__file__).parent / "student_pass_fail_model.joblib"

st.title("🎓 Student Pass/Fail Predictor")
st.write(
    "Enter student study and lifestyle details to get a prediction from the trained "
    "machine-learning model. This is an educational demo, not an official assessment."
)

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

model = load_model()

if model is None:
    st.warning(
        "The trained model file is not included yet. Run the Task 4 notebook first, "
        "export the fitted model as `student_pass_fail_model.joblib`, and place it "
        "beside this app.py file. See README.md for instructions."
    )
    st.stop()

st.subheader("Student information")

with st.form("student_inputs"):
    col1, col2 = st.columns(2)
    with col1:
        studytime = st.slider("Weekly study time (category 1–4)", 1, 4, 2)
        failures = st.slider("Past class failures", 0, 4, 0)
        absences = st.number_input("School absences", min_value=0, max_value=100, value=2)
        age = st.slider("Age", 15, 22, 17)
    with col2:
        goout = st.slider("Going out with friends (1–5)", 1, 5, 3)
        health = st.slider("Self-reported health (1–5)", 1, 5, 3)
        internet = st.selectbox("Internet access at home", ["yes", "no"])
        schoolsup = st.selectbox("Extra educational support", ["yes", "no"])
    submit = st.form_submit_button("Predict outcome")

if submit:
    input_df = pd.DataFrame([{
        "age": age,
        "Medu": 2,
        "Fedu": 2,
        "traveltime": 2,
        "studytime": studytime,
        "failures": failures,
        "schoolsup": schoolsup,
        "internet": internet,
        "goout": goout,
        "health": health,
        "absences": absences,
    }])
    try:
        prediction = model.predict(input_df)[0]
        label = str(prediction)
        if label.lower() in {"1", "pass", "passed"}:
            st.success("Predicted outcome: PASS")
        elif label.lower() in {"0", "fail", "failed"}:
            st.error("Predicted outcome: FAIL")
        else:
            st.info(f"Predicted class: {label}")
        if hasattr(model, "predict_proba"):
            probabilities = model.predict_proba(input_df)[0]
            st.caption("Model probability estimates:")
            st.write({str(cls): round(float(prob), 3) for cls, prob in zip(model.classes_, probabilities)})
        st.caption("Predictions are estimates and can be wrong; they should not be used to make real educational decisions.")
    except Exception as exc:
        st.error(
            "The saved model's expected input columns do not match this app's inputs. "
            "Update the input fields to match the exact features used when training the model."
        )
        st.exception(exc)
